const issues = [
    "How should we tackle climate change?",
    "What role do businesses play in sustainable development?",
    "Should governments prioritize economic growth over environmental sustainability?",
    "How can we ensure access to clean water for all?",
    "Should renewable energy be subsidized more by the government?"
];

let proVotes = 0;
let conVotes = 0;

document.getElementById('new-issue-btn').addEventListener('click', function() {
    const randomIssue = issues[Math.floor(Math.random() * issues.length)];
    document.getElementById('issue-text').innerText = randomIssue;
});

document.querySelectorAll('.vote-btn').forEach(button => {
    button.addEventListener('click', function() {
        const vote = this.getAttribute('data-vote');
        if (vote === 'Pro') {
            proVotes++;
        } else {
            conVotes++;
        }
        displayResults();
    });
});

function displayResults() {
    document.getElementById('results').innerText = `Pro Votes: ${proVotes}, Con Votes: ${conVotes}`;
}
