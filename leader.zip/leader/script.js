let resources = 100;
let povertyLevel = 50;
let educationLevel = 50;
let climateLevel = 50;

function allocateResources(goal) {
    if (resources >= 10) {
        resources -= 10;
        document.getElementById("resources").textContent = resources;

        if (goal === 'poverty') {
            povertyLevel += 5;
            educationLevel -= 2; // Trade-off
            document.getElementById('poverty-progress').value = povertyLevel;
            document.getElementById('education-progress').value = educationLevel;
            document.getElementById('message').textContent = "Improved poverty reduction, but education suffered!";
        } else if (goal === 'education') {
            educationLevel += 5;
            climateLevel -= 2; // Trade-off
            document.getElementById('education-progress').value = educationLevel;
            document.getElementById('climate-progress').value = climateLevel;
            document.getElementById('message').textContent = "Boosted education, but climate resilience weakened!";
        } else if (goal === 'climate') {
            climateLevel += 5;
            povertyLevel -= 2; // Trade-off
            document.getElementById('climate-progress').value = climateLevel;
            document.getElementById('poverty-progress').value = povertyLevel;
            document.getElementById('message').textContent = "Addressed climate action, but poverty increased!";
        }
    } else {
        document.getElementById('message').textContent = "Not enough resources!";
    }
}
