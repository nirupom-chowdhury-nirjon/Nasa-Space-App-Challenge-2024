const questions = [
    { 
        question: "What is SDG 1?", 
        answers: [{ text: "No Poverty", correct: true }, { text: "Zero Hunger", correct: false }], 
        impact: "Around 9.2% of the world population live in extreme poverty, earning less than $1.90 per day." 
    },
    { 
        question: "Which SDG focuses on Gender Equality?", 
        answers: [{ text: "SDG 3", correct: false }, { text: "SDG 5", correct: true }], 
        impact: "Gender inequality restricts access to education, employment, and participation in decision-making processes." 
    },
    { 
        question: "What does SDG 13 address?", 
        answers: [{ text: "Climate Action", correct: true }, { text: "Clean Water", correct: false }], 
        impact: "Climate change disrupts weather patterns and causes natural disasters." 
    },
    {
        question: "What is SDG 2?", 
        answers: [{ text: "Zero Hunger", correct: true }, { text: "Quality Education", correct: false }], 
        impact: "About 690 million people are undernourished, and eliminating hunger is a critical global challenge."
    },
    {
        question: "Which SDG promotes Quality Education?", 
        answers: [{ text: "SDG 4", correct: true }, { text: "SDG 10", correct: false }], 
        impact: "Quality education ensures inclusive and equitable learning opportunities for all individuals."
    },
    {
        question: "SDG 6 is related to which issue?", 
        answers: [{ text: "Clean Water and Sanitation", correct: true }, { text: "Affordable Energy", correct: false }], 
        impact: "Globally, 2.2 billion people lack access to safe drinking water, highlighting the need for sustainable water management."
    },
    {
        question: "What is the focus of SDG 7?", 
        answers: [{ text: "Affordable and Clean Energy", correct: true }, { text: "Decent Work", correct: false }], 
        impact: "Ensuring access to affordable and sustainable energy is key to reducing greenhouse gas emissions."
    },
    {
        question: "Which SDG targets Decent Work and Economic Growth?", 
        answers: [ { text: "SDG 16", correct: false },{ text: "SDG 8", correct: true }], 
        impact: "Promoting sustained economic growth and decent work opportunities improves living standards globally."
    },
    {
        question: "What does SDG 9 address?", 
        answers: [{ text: "Industry, Innovation, and Infrastructure", correct: true }, { text: "Life on Land", correct: false }], 
        impact: "Building resilient infrastructure and fostering innovation are essential for inclusive economic development."
    },
    {
        question: "Which SDG works towards reducing inequality within and among countries?", 
        answers: [{ text: "SDG 10", correct: true }, { text: "SDG 6", correct: false }], 
        impact: "Reducing inequality requires promoting equal opportunities for all, particularly for marginalized groups."
    },
    {
        question: "What is SDG 11?", 
        answers: [{ text: "Sustainable Cities and Communities", correct: true }, { text: "Responsible Consumption", correct: false }], 
        impact: "Sustainable urbanization is vital for managing global population growth and minimizing environmental impact."
    },
    {
        question: "Which SDG focuses on Responsible Consumption and Production?", 
        answers: [{ text: "SDG 12", correct: true }, { text: "SDG 14", correct: false }], 
        impact: "Sustainable consumption and production reduce waste, conserve resources, and lessen environmental degradation."
    },
    {
        question: "What is the focus of SDG 14?", 
        answers: [{ text: "Life Below Water", correct: true }, { text: "Life on Land", correct: false }], 
        impact: "Protecting marine ecosystems is crucial for biodiversity and for people who rely on oceans for their livelihoods."
    },
    {
        question: "Which SDG is Life on Land?", 
        answers: [{ text: "SDG 15", correct: true }, { text: "SDG 7", correct: false }], 
        impact: "Protecting, restoring, and promoting sustainable use of terrestrial ecosystems is essential for a healthy planet."
    },
    {
        question: "What does SDG 16 focus on?", 
        answers: [{ text: "Peace, Justice, and Strong Institutions", correct: true }, { text: "Good Health and Well-being", correct: false }], 
        impact: "Peaceful societies, justice, and accountable institutions are foundational to sustainable development."
    },
    {
        question: "Which SDG calls for Partnerships for the Goals?", 
        answers: [{ text: "SDG 17", correct: true }, { text: "SDG 1", correct: false }], 
        impact: "Achieving the SDGs requires global partnerships, financial resources, and collaborative efforts."
    },
    {
        question: "What percentage of the global population lacks access to safe drinking water?", 
        answers: [{ text: "2.2 billion", correct: true }, { text: "1.2 billion", correct: false }], 
        impact: "Globally, 2.2 billion people lack access to safely managed drinking water services."
    },
  {
    question: "What is the main focus of SDG 15?", 
    answers: [{ text: "Life on Land", correct: true }, { text: "Life Below Water", correct: false }], 
    impact: "SDG 15 focuses on protecting, restoring, and promoting sustainable use of terrestrial ecosystems."
},
{
    question: "Which SDG addresses affordable housing?", 
    answers: [{ text: "SDG 11", correct: true }, { text: "SDG 2", correct: false }], 
    impact: "SDG 11 aims to make cities inclusive, safe, resilient, and sustainable, including ensuring affordable housing."
},
{
    question: "What is the goal of SDG 5?", 
    answers: [{ text: "Gender Equality", correct: true }, { text: "Quality Education", correct: false }], 
    impact: "SDG 5 promotes gender equality and the empowerment of all women and girls."
},
{
    question: "What percentage of global energy is sourced from renewable energy?", 
    answers: [{ text: "17%", correct: true }, { text: "25%", correct: false }], 
    impact: "Only 17% of global energy consumption is sourced from renewable energy."
},
{
    question: "Which SDG aims to end hunger and ensure access to nutritious food?", 
    answers: [{ text: "SDG 2", correct: true }, { text: "SDG 6", correct: false }], 
    impact: "SDG 2 aims to end hunger, achieve food security, and improve nutrition by 2030."
},
{
    question: "Which SDG focuses on providing clean water and sanitation?", 
    answers: [{ text: "SDG 6", correct: true }, { text: "SDG 8", correct: false }], 
    impact: "SDG 6 aims to ensure availability and sustainable management of water and sanitation for all."
},
{
    question: "What is the main target of SDG 12?", 
    answers: [{ text: "Responsible Consumption and Production", correct: true }, { text: "Decent Work and Economic Growth", correct: false }], 
    impact: "SDG 12 focuses on ensuring sustainable consumption and production patterns."
},
{
    question: "Which SDG focuses on taking urgent action to combat climate change?", 
    answers: [{ text: "SDG 13", correct: true }, { text: "SDG 9", correct: false }], 
    impact: "SDG 13 calls for urgent action to combat climate change and its impacts."
},
{
    question: "What is the key goal of SDG 4?", 
    answers: [{ text: "Quality Education", correct: true }, { text: "Decent Work", correct: false }], 
    impact: "SDG 4 focuses on ensuring inclusive and equitable quality education for all."
},
{
    question: "Which SDG focuses on reducing inequalities within and among countries?", 
    answers: [{ text: "SDG 10", correct: true }, { text: "SDG 14", correct: false }], 
    impact: "SDG 10 promotes reducing inequalities, ensuring no one is left behind."
},
{
    question: "What does SDG 8 promote?", 
    answers: [{ text: "Decent Work and Economic Growth", correct: true }, { text: "Industry, Innovation, and Infrastructure", correct: false }], 
    impact: "SDG 8 promotes sustained, inclusive, and sustainable economic growth and decent work for all."
},
{
    question: "What is the focus of SDG 16?", 
    answers: [{ text: "Peace, Justice, and Strong Institutions", correct: true }, { text: "Affordable and Clean Energy", correct: false }], 
    impact: "SDG 16 focuses on promoting peaceful and inclusive societies and providing access to justice for all."
},
{
    question: "Which SDG addresses Life Below Water?", 
    answers: [{ text: "SDG 14", correct: true }, { text: "SDG 15", correct: false }], 
    impact: "SDG 14 aims to conserve and sustainably use the oceans, seas, and marine resources."
},
{
    question: "What percentage of the global population faces water scarcity?", 
    answers: [{ text: "40%", correct: true }, { text: "25%", correct: false }], 
    impact: "About 40% of the world’s population faces water scarcity, highlighting the urgency of SDG 6."
},
{
    question: "Which SDG aims to foster innovation and build resilient infrastructure?", 
    answers: [{ text: "SDG 9", correct: true }, { text: "SDG 7", correct: false }], 
    impact: "SDG 9 focuses on building resilient infrastructure and fostering innovation for sustainable development."
},
{
    question: "Which SDG targets the promotion of peaceful societies?", 
    answers: [{ text: "SDG 16", correct: true }, { text: "SDG 5", correct: false }], 
    impact: "SDG 16 promotes peaceful and inclusive societies, ensuring access to justice and building accountable institutions."
},
{
    question: "Which SDG focuses on sustainable use of terrestrial ecosystems?", 
    answers: [{ text: "SDG 15", correct: true }, { text: "SDG 13", correct: false }], 
    impact: "SDG 15 focuses on conserving and sustainably using terrestrial ecosystems, such as forests and land."
},
{
    question: "Which SDG promotes sustainable agriculture?", 
    answers: [{ text: "SDG 2", correct: true }, { text: "SDG 3", correct: false }], 
    impact: "SDG 2 focuses on ending hunger and promoting sustainable agriculture to ensure food security."
},
{
    question: "How many people worldwide lack access to electricity?", 
    answers: [{ text: "1 billion", correct: true }, { text: "500 million", correct: false }], 
    impact: "About 1 billion people worldwide still lack access to electricity, a key focus of SDG 7."
},
{
    question: "What is the main target of SDG 17?", 
    answers: [{ text: "Partnerships for the Goals", correct: true }, { text: "No Poverty", correct: false }], 
    impact: "SDG 17 aims to strengthen global partnerships to achieve the SDGs by 2030."
},
    {
        question: "Which SDG emphasizes Affordable and Clean Energy?", 
        answers: [{ text: "SDG 7", correct: true }, { text: "SDG 9", correct: false }], 
        impact: "Access to clean and affordable energy is crucial for combating climate change and ensuring economic growth."
    },
    {
        question: "How many people globally live in extreme poverty, on less than $1.90 per day?", 
        answers: [{ text: "9.2%", correct: true }, { text: "15%", correct: false }], 
        impact: "Over 9% of the world population still lives in extreme poverty, facing significant social and economic challenges."
    },
    {
        question: "Which SDG advocates for Zero Hunger?", 
        answers: [{ text: "SDG 2", correct: true }, { text: "SDG 6", correct: false }], 
        impact: "Eliminating hunger is vital for improving health and ensuring long-term prosperity for communities worldwide."
    },
    {
        question: "Which SDG aims to reduce income inequality?", 
        answers: [{ text: "SDG 10", correct: true }, { text: "SDG 8", correct: false }], 
        impact: "Reducing income inequality ensures that economic growth benefits everyone, regardless of social or economic status."
    },
    {
        question: "What is SDG 3 about?", 
        answers: [{ text: "Good Health and Well-being", correct: true }, { text: "Climate Action", correct: false }], 
        impact: "Ensuring healthy lives and promoting well-being for all at all ages is a cornerstone of sustainable development."
    },
    {
        question: "Which SDG addresses Clean Water and Sanitation?", 
        answers: [{ text: "SDG 6", correct: true }, { text: "SDG 14", correct: false }], 
        impact: "Ensuring access to clean water and sanitation for all is essential for human health and environmental protection."
    },
    {
        question: "What percentage of the world’s energy comes from renewable sources?", 
        answers: [{ text: "17%", correct: true }, { text: "35%", correct: false }], 
        impact: "Currently, about 17% of the world’s energy consumption is sourced from renewable sources, but much more is needed."
    },
    {
        question: "Which SDG focuses on Decent Work and Economic Growth?", 
        answers: [{ text: "SDG 8", correct: true }, { text: "SDG 12", correct: false }], 
        impact: "Creating decent work opportunities fosters economic growth and improves living conditions globally."
    },
    {
        question: "What percentage of global waste is recycled?", 
        answers: [{ text: "20%", correct: true }, { text: "45%", correct: false }], 
        impact: "Only about 20% of global waste is recycled, underscoring the need for better waste management systems."
    },
    {
        question: "Which SDG promotes sustainable management of forests?", 
        answers: [{ text: "SDG 15", correct: true }, { text: "SDG 11", correct: false }], 
        impact: "Sustainable management of forests is crucial for biodiversity, climate regulation, and human livelihoods."
    },
    {
        question: "Which SDG advocates for sustainable use of marine resources?", 
        answers: [{ text: "SDG 14", correct: true }, { text: "SDG 16", correct: false }], 
        impact: "Oceans provide key resources, yet they are under increasing threat from pollution, overfishing, and climate change."
    },
    {
        question: "How much food is wasted globally every year?", 
        answers: [{ text: "1.3 billion tons", correct: true }, { text: "500 million tons", correct: false }], 
        impact: "An estimated 1.3 billion tons of food are wasted globally each year, contributing to significant environmental and economic costs."
    },
    {
        question: "What is the goal of SDG 12?", 
        answers: [{ text: "Responsible Consumption and Production", correct: true }, { text: "No Poverty", correct: false }], 
        impact: "Ensuring sustainable consumption and production patterns is essential for minimizing waste and conserving resources."
    },
    {
        question: "Which SDG addresses global partnerships?", 
        answers: [{ text: "SDG 17", correct: true }, { text: "SDG 8", correct: false }], 
        impact: "Global partnerships are necessary to mobilize resources and strengthen cooperation towards achieving the SDGs."
    },
    {
        question: "What does SDG 9 address?", 
        answers: [{ text: "Industry, Innovation, and Infrastructure", correct: true }, { text: "Quality Education", correct: false }], 
        impact: "Building resilient infrastructure and fostering innovation are vital for economic growth and development."
    }
    // You can continue adding more questions in the same format here if needed
];


let currentQuestionIndex = 0;
let score = 0;
const maxScore = questions.length;
const questionContainer = document.getElementById('question-container');
const impactContainer = document.getElementById('impact-container'); // Impact container
const nextButton = document.getElementById('next-button');
const scoreDisplay = document.getElementById('score');
const progressBar = document.getElementById('myBar');

function showQuestion(question) {
    questionContainer.innerHTML = `<h2>${question.question}</h2>`;
    impactContainer.style.display = 'none'; // Hide the impact container initially
    question.answers.forEach(answer => {
        const button = document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('btn');
        button.addEventListener('click', () => selectAnswer(answer, question.impact));
        questionContainer.appendChild(button);
    });
}

function selectAnswer(answer, impact) {
    if (answer.correct) {
        score++;
        scoreDisplay.innerText = score;
        updateProgressBar();
        alert("Correct!");
    } else {
        alert("Wrong! Try again.");
    }
    // Show impact statement
    showImpact(impact);
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        questionContainer.innerHTML = '';
        setTimeout(() => showQuestion(questions[currentQuestionIndex]), 6000); // Wait 2 seconds before showing the next question
    } else {
        questionContainer.innerHTML = '<h2>Quiz Completed! Final Score: ' + score + '/' + maxScore + '</h2>';
        nextButton.style.display = 'block';
    }
}

function showImpact(impact) {
    impactContainer.innerHTML = `<p><strong>Impact:</strong> ${impact}</p>`;
    impactContainer.style.display = 'block';
}

function updateProgressBar() {
    const progressPercent = (score / maxScore) * 100;
    progressBar.style.width = progressPercent + '%';
    progressBar.innerText = score + '/' + maxScore;
}

nextButton.addEventListener('click', () => {
    currentQuestionIndex = 0;
    score = 0;
    scoreDisplay.innerText = score;
    progressBar.style.width = '0%';
    nextButton.style.display = 'none';
    showQuestion(questions[currentQuestionIndex]);
});

showQuestion(questions[currentQuestionIndex]);
